# Comp1239Assignment1
Sports Technical Manager using MVC model, CRUD operations with db
